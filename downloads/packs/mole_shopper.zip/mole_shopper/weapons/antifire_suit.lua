-- Antifire Suit: protect the wearer from flames and repel nearby fire until their team's next turn.

local ID = "px.antifire_suit"
local ART = "sprites/antifire_suit/"
local SOUND = "sounds/antifire_suit/putting_on_suit.wav"
local RADIUS, POWER = 28, 28
local IDLE_ALPHA, HIT_ALPHA = 38, 120
local M = {}

function M.install(ctx)
  local function option(key, default)
    if ctx and ctx.option then return ctx.option(key) end
    return default
  end
  local seconds = option("duration", 0)
  local turns = option("turns", 1)
  local suits, smoke = {}, {}
  local function alive(w)
    return w.id ~= 0 and w.hp > 0 and w.state ~= "dying"
      and w.state ~= "drowning" and w.state ~= "dead"
  end
  local function alpha(s, now)
    return math.max(IDLE_ALPHA, s.alpha - 2 * math.max(0, now - s.refreshed - 51))
  end
  -- Its icon in the utility tray while it's on (shown on the wearer's turns).
  local function off(id)
    local s = suits[id]
    if s and s.icon then s.icon:remove() end
    suits[id] = nil
  end
  local function flash(s)
    local now = wa.world.frame()
    s.alpha, s.refreshed = HIT_ALPHA, now
  end
  wa.weapons.replace{
    copy_from = "stock.double_turn_time", name = "Antifire Suit",
    panel_icon = ART .. "icon.png",
    handling = {remember_selection = false, ends_turn = false, retreat = -1},
    utility = {effect = "scripted"},
    sprites = {ART .. "shield.png", ART .. "smoke.png"}, sounds = {SOUND}, params = {gpu_prefix = ART},
    on_fire = function(ev)
      local w = ev.worm
      if not alive(w) or suits[w.id] then return end
      local now = wa.world.frame()
      suits[w.id] = {team = w.team, alpha = IDLE_ALPHA, refreshed = now,
        turns = turns, ends = seconds > 0 and now + seconds * 50 or nil}
      local tray = wa.hud and wa.hud.utilities
      if tray then suits[w.id].icon = tray.add{ weapon = ID, worm = w } end
      wa.sound.play(w, SOUND)
      require("wf-lib/tooltip").notice(w, "Antifire Suit ON")
    end,
  }
  wa.on.hurt(function(hit)
    local w = hit.worm
    local s = suits[w.id]
    if hit.phase == "pre" and hit.kind == "fire" and s and alive(w) then
      flash(s)
      local now = wa.world.frame()
      if wa.world.turn_clock() > 0 then
        if now % 2 == 0 and s.sizzled ~= now then
          s.sizzled = now
          wa.sound.play(w, 55)
        end
        if now % 5 == 0 and s.smoked ~= now then
          s.smoked = now
          for i = #smoke, 1, -1 do
            if now - smoke[i].born >= 60 then table.remove(smoke, i) end
          end
          if #smoke < 256 then
            smoke[#smoke + 1] = {id = w.id, x = w.x, y = w.y, born = now,
              vx = (now % 3 - 1) * 0.3}
          end
        end
      end
      return "eat"
    end
  end)
  wa.on.worm_message(function(w, msg)
    if msg == wa.msg.TURN_STARTED then
      if not w.turn then return end
      for _, id in ipairs(wa.sorted(suits)) do
        local s = suits[id]
        if s.team == w.team and not s.ends then
          s.turns = s.turns - 1
          if s.turns <= 0 then off(id) end
        end
      end
      return
    end
    local s = suits[w.id]
    if not s then return end
    if not alive(w) or (s.ends and wa.world.frame() >= s.ends) then off(w.id); return end
    wa.fire.repel{x = w.x, y = w.y, radius = RADIUS, power = POWER}
  end, {msgs = {wa.msg.FRAME_FINISH, wa.msg.TURN_STARTED}})
  wa.on.death(function(ev) off(ev.victim.id) end)
  wa.on.turn_cleanup(function()
    for _, id in ipairs(wa.sorted(suits)) do
      if suits[id].ends then off(id) end
    end
  end)
  -- Made once, and one table of the living worms emptied each frame: the
  -- draw makes no tables of its own.
  local SHIELD = wa.draw.brush{ sprite = ART .. "shield.png", depth = wa.depth.WORMS - 1, blend = "add" }
  local SMOKE = wa.draw.brush{ sprite = ART .. "smoke.png", depth = wa.depth.WORMS - 2 }
  local SHIELD_SIZE = 2 * 25 * 0.85
  local living = {}
  wa.on.draw(function()
    local now = wa.world.frame()
    for id in pairs(living) do living[id] = nil end
    for _, w in ipairs(wa.worms.all()) do
      living[w.id] = w
      local s = suits[w.id]
      if s and alive(w) then
        local a = math.floor(alpha(s, now))
        if a > 0 then
          SHIELD:box(w.x, w.y, SHIELD_SIZE, SHIELD_SIZE, 0, nil, (a << 24) | 0xFF0000, w)
        end
      end
    end
    for i = #smoke, 1, -1 do
      local p = smoke[i]
      local age, w = now - p.born, living[p.id]
      if age >= 60 or not w or not alive(w) then table.remove(smoke, i)
      else
        local x, y = p.x + p.vx * age, p.y - 0.375 * age - 0.03 * age * age
        local opacity = math.floor(200 * (1 - age / 60))
        SMOKE:box(x, y, 44, 44, 0, math.min(27, math.floor(age * 28 / 60)), (opacity << 24) | 0xFFFFFF, w)
      end
    end
  end)
end

return M
