-- Sniper Rifle: a rifle with a laser sight: one precise shot.

local weapon = {}

weapon.record = {
  handling = {
    shots = 3,
  },
  gun = {
    bullets = 1,
    damage = 18,
    explosion = {
      push_pct = 100,
      variation = 50,
    },
    hits = {
      arrows = true,
      crates = true,
      donor_cards = true,
      land = true,
      mines = true,
      objects = true,
      water = true,
      worms = true,
      worms_frozen = true,
    },
    impact_effect = 7,
    shot_interval_ms = 1000,
    spread_deg = 0,
  },
}

function weapon.definition()
  local sdk = require("wf-lib/holds")
  local PX_POSTURE = sdk.PX_POSTURE
  return require("lib/weapon").merge(weapon.record, {
    copy_from = "stock.handgun",
    name = "Sniper Rifle",
    crosshair = false, -- the laser sight aims it
    panel_icon = "sprites/sniper_rifle/srico.png",
    worm_sprites = {
          weaponlnk = PX_POSTURE.weaponlnk, weaponlnku = PX_POSTURE.weaponlnku,
          weaponlnkd = PX_POSTURE.weaponlnkd,
          wthrow = PX_POSTURE.wthrow, wthrowu = PX_POSTURE.wthrowu, wthrowd = PX_POSTURE.wthrowd,
          weaponfire = "sprites/sniper_rifle/fire.png", weaponfireu = "sprites/sniper_rifle/fireu.png",
          weaponfired = "sprites/sniper_rifle/fired.png",
        },
    sprites = {
          "sprites/px_hold/sniper_rifle.png", "sprites/sniper_rifle/laser.png", "sprites/sniper_rifle/flash.png",
        },
    sounds = { "sounds/sniper_firing.wav" },
    params = { gpu_prefix = "sprites/" },
    hold = {
        keep_while_firing = true,
        put_away = true,
        flash = { sheet = "sprites/sniper_rifle/flash.png", out = 30, side = 2, scale = 0.45, frames = 3 },
        sheet = "sprites/px_hold/sniper_rifle.png", draw_hand = false, hand_radius = -6.0,
        hand_rotation = 1.0, hand_radial_rotation = 0.9,
        weap_rotation = 1.0, weap_radial_rotation = 0.0, weap_radius = 0.1,
      },
  })
end

function weapon.setup()
  local shared = require("lib/shared")

  local held = {}
  wa.on.worm_message(function(worm, msg)
    local h = held[worm.id]
    if msg == wa.msg.FIRE_WEAPON and h then h.firing = true end
    if msg == wa.msg.FIRE_WEAPON and worm.weapon == "px.sniper_rifle"
        and worm:ammo("px.sniper_rifle") ~= 0 then
      wa.sound.play(worm, "sounds/sniper_firing.wav")
    end
    if msg ~= wa.msg.FRAME_FINISH then return end
    if worm.weapon == "px.sniper_rifle" and worm.aiming and shared.owns("px.sniper_rifle") then
      held[worm.id] = { weapon = "px.sniper_rifle", aim = worm.aim }
    elseif not (h and h.firing and worm.weapon == "px.sniper_rifle"
        and (worm.state == "firing" or worm.state == "fired")) then
      held[worm.id] = nil
    end
  end, { msgs = { wa.msg.FIRE_WEAPON, wa.msg.FRAME_FINISH } })

  local STOPPERS
  do

  local LASER_LEN = 15000
  local LASER_WIDTH = 2
  local LASER_STEP = 5 -- PX's Trace tests every 5 pixels
  local LASER_BARREL = 2
  local function argb(a, r, g, b)
    return ((a * 256 + r) * 256 + g) * 256 + b
  end
  local LASER_RED, LASER_START, LASER_TIP =
    argb(255, 255, 48, 48), argb(192, 255, 96, 96), argb(16, 255, 48, 48)
  STOPPERS = { { wa.worms, 6 }, { wa.mines, 4 }, { wa.crates, 10 }, { wa.oil, 9 } }

  local function laser_length(x, y, dx, dy, shooter)
    local len = LASER_LEN
    local hit = wa.land.trace(x, y,
      (x + dx * LASER_LEN), (y + dy * LASER_LEN))
    if hit then
      len = math.sqrt(((hit.x - x) * (hit.x - x)) + ((hit.y - y) * (hit.y - y)))
    end
    for _, s in ipairs(STOPPERS) do
      local list, r = s[1], s[2]
      if list and list.all then
        for _, o in ipairs(list.all()) do
          if o.id ~= shooter then
            local ox, oy = (o.x - x), (o.y - y)
            local t = ox * dx + oy * dy
            if t > 0 and t < len and math.abs(ox * dy - oy * dx) < r then
              len = t
            end
          end
        end
      end
    end
    return math.floor(len / LASER_STEP) * LASER_STEP
  end

  local function laser_ray(x, y, ang, len, worm)
    local rdx, rdy = wa.math.sin(ang - 1.57), -wa.math.cos(ang - 1.57)
    local dx, dy = wa.math.sin(ang), -wa.math.cos(ang)
    local tx, ty = x, y
    local nparts = math.floor(len / 100)
    local w = (wa.draw.random() / 4 + 0.85) * LASER_WIDTH / 2
    local wdx, wdy = w * rdx, w * rdy
    local wscale = 1
    local lastl = len - nparts * 100
    local colors
    for i = 0, nparts do
      local l = i == nparts and lastl or 100
      if l <= 0 then break end
      local p0, p3 = { tx + wdx, ty + wdy }, { tx - wdx, ty - wdy }
      w = wscale * (wa.draw.random() / 3 + 0.82) * LASER_WIDTH
      wdx, wdy = w * rdx, w * rdy
      wscale = wscale - 0.75 / (nparts + 1)
      local ex, ey = tx + dx * l, ty + dy * l
      colors = { LASER_RED, LASER_RED, LASER_RED, LASER_RED }
      if i == 0 then
        colors[1], colors[4] = LASER_START, LASER_START
      end
      wa.draw.quad({
        points = { p0, { ex + wdx, ey + wdy }, { ex - wdx, ey - wdy }, p3 },
        colors = colors, sprite = "sprites/sniper_rifle/laser.png", blend = "add", visibility = worm,
      })
      tx, ty = ex, ey
    end
    local ex, ey = tx + dx * 7, ty + dy * 7
    wa.draw.quad({
      points = { { tx + wdx, ty + wdy }, { ex + wdx, ey + wdy }, { ex - wdx, ey - wdy }, { tx - wdx, ty - wdy } },
      colors = { LASER_RED, LASER_TIP, LASER_TIP, LASER_RED },
      sprite = "sprites/sniper_rifle/laser.png", blend = "add", visibility = worm,
    })
  end

  if wa.on.draw then
    wa.on.draw(function()
      for _, worm in ipairs(wa.worms.all()) do
        local h = worm.turn and held[worm.id]
        local aim = h and h.weapon == "px.sniper_rifle" and h.aim
        if aim then
          local ang = (1 - aim) * 3.14159
          if worm.facing < 0 then
            ang = 6.28318 - ang
          end
          local side = LASER_BARREL * worm.facing
          local x = worm.x + wa.math.sin(ang) * 12 - wa.math.cos(ang) * side
          local y = worm.y - wa.math.cos(ang) * 12 - wa.math.sin(ang) * side
          laser_ray(x, y, ang, laser_length(x, y, wa.math.sin(ang), -wa.math.cos(ang), worm.id), worm)
        end
      end
    end)
  end
  end

end

return weapon
